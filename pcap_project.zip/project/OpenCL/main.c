#include "image10.h"
#include "sobel2.h"

int main(int argc, char **argv)
{
        read_png_file(argv[1]);

        int height = getHeight();
        int width = getWidth();

        
        int *src = malloc(sizeof(int) * height * width);
        int *dest = malloc(sizeof(int) * height * width);
        
        clock_t start, end;
        double time_taken;

        png_to_arr(src);
        start = clock();
        sobel_sequential(src, dest, height, width);
        end = clock();
        arr_to_png(dest);

        write_png_file(argv[2]);
        
        time_taken = ((double)end - start)/CLOCKS_PER_SEC * 1000;
        printf("Sequential Time : %lf ms\n", time_taken);
}
