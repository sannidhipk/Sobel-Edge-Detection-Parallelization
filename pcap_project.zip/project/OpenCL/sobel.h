#ifndef __SOBEL_H__
#define __SOBEL_H__

//#define SOBEL_THRESHOLD 70

#define MAX(a, b) ((a) > (b) ? (a) : (b))

const int smask_3_y[3][3] = {
    {+1, +2, +1},
    { 0,  0,  0},
    {-1, -2, -1}
};

const int smask_3_x[3][3] = {
    {-1, 0, +1},
    {-2, 0, +2},
    {-1, 0, +1}
};

#endif
