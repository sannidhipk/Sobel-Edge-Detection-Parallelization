#include "sobel.h"
#include <math.h>

int compute_gradient(int *src, int m, int n, int i, int j, const int mask[3][3])
{
    if(i - 1 < 0 || i + 1 >= m || j - 1 < 0 || j + 1 >= n)
        return 0;
    int ans = 0;
    for(int k = 0; k < 3; ++k) {
        for(int l = 0; l < 3; ++l) {
            ans += src[(i - 1 + k) * n + (j - 1 + l)] * mask[k][l];
        }
    }

    return ans;
}

void sobel_sequential(int *src, int *dst, int m, int n)
{
    int scale_factor = -1;
    for(int i = 0; i < m; ++i) {
        for(int j = 0; j < n; ++j) {
            int grad_x = compute_gradient(src, m, n, i, j, smask_3_x);
            int grad_y = compute_gradient(src, m, n, i, j, smask_3_y);
            //dst[i*n + j] = abs(grad_x) + abs(grad_y);
            dst[i*n + j] = round(sqrt(grad_x * grad_x + grad_y * grad_y));
            scale_factor = MAX(scale_factor, dst[i*n + j]);
        }
    }
    for(int i = 0; i < m; ++i)
        for(int j = 0; j < n; ++j)
            dst[i*n + j] = round(255.0/scale_factor * dst[i*n + j]);
}
