#include <stdio.h>
#include <CL/cl.h>
#include "image10.h"

int STRIP_COUNT;
#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) > (b) ? (b) : (a))

int read_kernel(char *file, char *src_str, size_t *src_len)
{
        FILE *fp = fopen(file, "r");
        if(!fp) {
                printf("Error opening file!\n");
                return 0;
        }
        *src_len = fread(src_str, sizeof(char), 102400, fp);
        fclose(fp);
        
        return 1;
}

int main(int argc, char **argv)
{
        char *src_str = malloc(sizeof(char) * 102400);
        size_t src_len;

        if(!read_kernel("sobel.cl", src_str, &src_len)) {
            printf("Error reading kernel\n");
            return 1;
        }
        char *src_str2 = malloc(sizeof(char) * 102400);
        size_t src_len2;
        if(!read_kernel("scale_max.cl", src_str2, &src_len2)) {
            printf("Error reading kernel\n");
            return 1;
        }
        read_png_file(argv[1]);

        int height = getHeight();
        int width = getWidth();
        STRIP_COUNT = MIN(256*256, height);
        STRIP_COUNT += (STRIP_COUNT) % 32;

        int *src_img = malloc(sizeof(int) * height * width);
        png_to_arr(src_img);

        cl_platform_id platform_id;
        cl_device_id device_id;
        cl_int ret;

        clGetPlatformIDs(1, &platform_id, NULL);
        clGetDeviceIDs(platform_id, CL_DEVICE_TYPE_GPU, 1, &device_id, NULL);

        cl_context context = clCreateContext(NULL, 1, &device_id, NULL, NULL, &ret);
        cl_command_queue cq = clCreateCommandQueue(context, device_id, CL_QUEUE_PROFILING_ENABLE, NULL);

        cl_mem a_mem_obj = clCreateBuffer(context, CL_MEM_READ_ONLY, sizeof(int) * width * height, NULL, &ret);
        cl_mem b_mem_obj = clCreateBuffer(context, CL_MEM_READ_WRITE, sizeof(int) * width * height, NULL, &ret);
        cl_mem c_mem_obj = clCreateBuffer(context, CL_MEM_READ_WRITE, sizeof(int) * STRIP_COUNT, NULL, &ret);

        clEnqueueWriteBuffer(cq, a_mem_obj, CL_TRUE, 0, sizeof(int) * width * height, src_img, 0, NULL, NULL);

        cl_program program = clCreateProgramWithSource(context, 1, (const char **)&src_str, (const size_t *)&src_len, &ret);
        cl_program program2 = clCreateProgramWithSource(context, 1, (const char **)&src_str2, (const size_t *)&src_len2, &ret);

        ret = clBuildProgram(program, 1, &device_id, NULL, NULL, NULL);
        if (ret == CL_BUILD_PROGRAM_FAILURE) {
            // Determine the size of the log
            size_t log_size;
            clGetProgramBuildInfo(program, device_id, CL_PROGRAM_BUILD_LOG, 0, NULL, &log_size);

            // Allocate memory for the log
            char *log = (char *) malloc(log_size);

            // Get the log
            clGetProgramBuildInfo(program, device_id, CL_PROGRAM_BUILD_LOG, log_size, log, NULL);

            // Print the log
            fprintf(stderr, "%s\n", log);
            free(log); return 1;
        }
            
            ret = clBuildProgram(program2, 1, &device_id, NULL, NULL, NULL);

        if (ret == CL_BUILD_PROGRAM_FAILURE) {
            // Determine the size of the log
            size_t log_size;
            clGetProgramBuildInfo(program, device_id, CL_PROGRAM_BUILD_LOG, 0, NULL, &log_size);

            // Allocate memory for the log
            char *log = (char *) malloc(log_size);

            // Get the log
            clGetProgramBuildInfo(program, device_id, CL_PROGRAM_BUILD_LOG, log_size, log, NULL);

            // Print the log
            fprintf(stderr, "%s\n", log);
            free(log); return 1;
        }

        cl_kernel kernel = clCreateKernel(program, "sobel", &ret);
        cl_kernel kernel2 = clCreateKernel(program2, "scale_max", &ret);

        clSetKernelArg(kernel, 0, sizeof(cl_mem), &a_mem_obj);
        clSetKernelArg(kernel, 1, sizeof(cl_mem), &b_mem_obj);
        clSetKernelArg(kernel, 2, sizeof(int), &height);
        clSetKernelArg(kernel, 3, sizeof(int), &width);
        clSetKernelArg(kernel, 4, sizeof(cl_mem), &c_mem_obj);
        clSetKernelArg(kernel, 5, sizeof(int), &STRIP_COUNT);

        size_t global_work_size = STRIP_COUNT;
        //size_t local_work_size = 1;

        cl_event event;
        clEnqueueNDRangeKernel(cq, kernel, 1, 0, &global_work_size, NULL, 0, NULL, &event);
        clFinish(cq);

        int *local_max = malloc(sizeof(int) * STRIP_COUNT);
        clEnqueueReadBuffer(cq, c_mem_obj, CL_TRUE, 0, sizeof(int) * STRIP_COUNT, local_max, 0, NULL, NULL);
        clFinish(cq);

        int global_max = -1;
        for(int i = 0; i < STRIP_COUNT; ++i) {
            global_max = MAX(global_max, local_max[i]);
        }

        clSetKernelArg(kernel2, 0, sizeof(cl_mem), &a_mem_obj);
        clSetKernelArg(kernel2, 1, sizeof(cl_mem), &b_mem_obj);
        clSetKernelArg(kernel2, 2, sizeof(int), &height);
        clSetKernelArg(kernel2, 3, sizeof(int), &width);
        clSetKernelArg(kernel2, 4, sizeof(int), &global_max);
        clSetKernelArg(kernel2, 5, sizeof(int), &STRIP_COUNT);

        cl_event event2;
        clEnqueueNDRangeKernel(cq, kernel2, 1, 0, &global_work_size, NULL, 0, NULL, &event2);
        clFinish(cq);

        cl_ulong end_time, start_time;
        clGetEventProfilingInfo(event, CL_PROFILING_COMMAND_START, sizeof(start_time), &start_time, NULL);
        clGetEventProfilingInfo(event, CL_PROFILING_COMMAND_END, sizeof(end_time), &end_time, NULL);
        double total_time = end_time - start_time;
        clGetEventProfilingInfo(event2, CL_PROFILING_COMMAND_START, sizeof(start_time), &start_time, NULL);
        clGetEventProfilingInfo(event2, CL_PROFILING_COMMAND_END, sizeof(end_time), &end_time, NULL);
        total_time += end_time - start_time;
        printf("OpenCL Time = %lf ms\n", total_time/1000000);
        //printf("%lf\n", total_time/1000000);

        clEnqueueReadBuffer(cq, b_mem_obj, CL_TRUE, 0, sizeof(int) * width * height, src_img, 0, NULL, NULL);

        // Output the png
        arr_to_png(src_img);
        write_png_file(argv[2]);

        clReleaseKernel(kernel);
        clReleaseKernel(kernel2);
        clReleaseProgram(program);
        clReleaseProgram(program2);
        clReleaseMemObject(a_mem_obj);
        clReleaseMemObject(b_mem_obj);
        clReleaseMemObject(c_mem_obj);
        clReleaseCommandQueue(cq);
        clReleaseContext(context);
}

