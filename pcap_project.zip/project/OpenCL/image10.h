/*
 * sudo apt-get install libpng16-16
 * http://www.libpng.org/pub/png/libpng-manual.txt
 */

#include <stdlib.h>
#include <stdio.h>
#include <png.h>

int width, height;
png_bytep *row_pointers;
int row_bytes;

void read_png_file(char *filename)
{
        FILE *fp = fopen(filename, "rb");
        png_structp png = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
        if(!png)
                abort();

        png_infop info = png_create_info_struct(png);
        if(!info)
                abort();

        png_init_io(png, fp); //store file as png struct
        png_read_info(png, info);

        width      = png_get_image_width(png, info);
        height     = png_get_image_height(png, info);

        row_bytes = png_get_rowbytes(png, info);
        row_pointers = (png_bytep*)malloc(sizeof(png_bytep) * height);
        for(int y = 0; y < height; y++)
        {
                row_pointers[y] = (png_byte*)malloc(png_get_rowbytes(png,info));
        }

        png_read_image(png, row_pointers);

        fclose(fp);
}

void write_png_file(char *filename)
{
        FILE *fp = fopen(filename, "wb");
        if(!fp)
                abort();

        png_structp png = png_create_write_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
        if (!png)
                abort();

        png_infop info = png_create_info_struct(png);
        if (!info)
                abort();

        if (setjmp(png_jmpbuf(png)))
                abort();

        png_init_io(png, fp);

        png_set_IHDR(png, info, width, height, 8, PNG_COLOR_TYPE_GRAY, PNG_INTERLACE_NONE, PNG_COMPRESSION_TYPE_DEFAULT, PNG_FILTER_TYPE_DEFAULT);
        png_write_info(png, info);

        png_write_image(png, row_pointers);
        png_write_end(png, NULL);

        for(int y = 0; y < height; y++)
        {
                free(row_pointers[y]);
        }
        free(row_pointers);

        fclose(fp);
}

void png_to_arr(int *dst)
{
        for(int y = 0; y < height; y++)
        {
                png_bytep row = row_pointers[y];
               // printf("ROW BYTES = %d\n", row_bytes);
                png_bytep newrow = (png_byte*)malloc(row_bytes/4);
                for(int x = 0; x < width; x++)
                {
                        png_bytep px = &(row[x * 4]);
                        png_bytep newpx = &(newrow[x]);
                        newpx[0] = 0.21*px[0] + 0.72*px[1] + 0.07*px[2];
                        dst[y * width + x] = newpx[0];
                }
        }
}

void arr_to_png(int * src)
{
        for(int y = 0; y < height; y++)
        {
                png_bytep newrow = (png_byte*)malloc(row_bytes/4);
                for(int x = 0; x < width; x++)
                {
                        png_bytep newpx = &(newrow[x]);
                        newpx[0] = src[y*width+x];
                }
                row_pointers[y] = newrow;
        }
}

int getHeight()
{
        return height;
}

int getWidth()
{
        return width;
}
