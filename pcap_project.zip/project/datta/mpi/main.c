#include "image10.h"
#include "sobel2.h"
#include <mpi.h>

int main(int argc, char** argv)
{
	int rank, size;
	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Comm_size(MPI_COMM_WORLD, &size);
	MPI_Status stat;

	FILE *fp = getFile("Mario.png");
	int height = getHeight();
	int width = getWidth();
	int *src = malloc(sizeof(int)*height*width);
	int *dest = malloc(sizeof(int)*height*width);
	int *blocksrc = malloc(sizeof(int)*width*(height/size+2));
	int *blockdest = malloc(sizeof(int)*width*(height/size));

	if(rank==0)
	{
		for(int i=0; i<height*width; i++)
		{
			fscanf(fp, "%d", &src[i]);
	//		printf("%d\n", src[i]);
		}
	}

	MPI_Scatter(src, width*(height/size), MPI_INT, blocksrc, width*(height/size), MPI_INT, 0, MPI_COMM_WORLD);
    if(rank!=0)
    {
    	MPI_Send(blocksrc, width*2, MPI_INT, rank-1, 0, MPI_COMM_WORLD);
    }
    if(rank!=size-1)
    {
    	MPI_Recv(&blocksrc[width*(height/size)], width*2, MPI_INT, rank+1, 0, MPI_COMM_WORLD, &stat);
    }
	sobel_sequential(blocksrc, blockdest, height/size+2, width);
    MPI_Gather(&blockdest[width], width*(height/size), MPI_INT, dest, width*(height/size), MPI_INT, 0, MPI_COMM_WORLD);
//	putFile(src, "Mario2.png");
    if(rank == 0)
    	putFile(dest, "Mario3.png");
    MPI_Finalize();
}
